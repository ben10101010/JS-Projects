const Discord = require('discord.js');
module.exports={
    name: 'supportseal',
    description: "supports seals",
    execute(message, args){
      message.channel.send("SUPPORT DA BABY SEALS, AND WHERES THAT SIPPERLY SEAL!");
    }
  }