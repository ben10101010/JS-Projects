 const db = require('quick.db');
const Discord = require('discord.js')
const ms = require('ms')
const disbut = require('discord-buttons')
module.exports={
    name: 'balance',
    description: "Checks your balance",
    guildOnly: true,
    botDevs : true,
    args: true,
    async execute(message, args){
      
    }
}
