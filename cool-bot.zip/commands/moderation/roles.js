module.exports = {
	name: 'role',
	args: true,
    guildOnly: true,
	execute(message, args) {
	
	}
};