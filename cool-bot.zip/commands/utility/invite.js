const Discord = require('discord.js');
module.exports={
    name: 'invite',
    description: "invites to main server",
    execute(message, args){
      message.reply('https://discord.gg/q3AFBZkg53');
    }
  }