const db = require('quick.db');
const Discord = require('discord.js')
const ms = require('ms')
const disbut = require('discord-buttons')
module.exports={
    name: 'profile',
    description: "Checks your profile stats",
    guildOnly: true,
    async execute(message, args){
      
    }
}