module.exports={
    name: 'play',
    description: "makes the bot play music in the voice channel",
    guildOnly: true,
    args: true,
    async execute(message, args){

    }
}